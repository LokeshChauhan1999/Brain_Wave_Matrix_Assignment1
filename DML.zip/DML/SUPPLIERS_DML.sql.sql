REM INSERTING into SUPPLIERS
SET DEFINE OFF;
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (1,'Global Books Ltd.','Phone: +919876543210, Email: contact@globalbooks.com');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (2,'Tech Publishing House','Phone: +919123456789, Email: info@techpubhouse.co.uk');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (3,'Educational Resources Inc.','Phone: +919087654321, Email: sales@edu-resources.in');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (4,'Book Distributors LLC','Phone: +919234567890, Email: support@bookdistributors.com');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (5,'Library Essentials Co.','Phone: +919345678901, Email: inquiries@libraryessentials.com.au');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (6,'Novelty Books','Phone: +919456789012, Email: contact@noveltybooks.de');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (7,'Global Print Solutions','Phone: +919567897623, Email: info@printsolutions.fr');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (8,'Academic Publishers','Phone: +919678901234, Email: contact@academicpub.jp');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (9,'Elite Texts','Phone: +919789012345, Email: info@elitetexts.co.za');
Insert into SUPPLIERS (SUPPLIER_ID,SUPPLIER_NAME,CONTACT_INFO) values (10,'Books Unlimited','Phone: +919890123456, Email: support@booksunlimited.com');
