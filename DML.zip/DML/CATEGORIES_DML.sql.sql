REM INSERTING into CATEGORIES
SET DEFINE OFF;
Insert into CATEGORIES (CATEGORY_ID,CATEGORY_NAME) values (1,'Fiction');
Insert into CATEGORIES (CATEGORY_ID,CATEGORY_NAME) values (2,'Non-Fiction');
Insert into CATEGORIES (CATEGORY_ID,CATEGORY_NAME) values (3,'Science');
Insert into CATEGORIES (CATEGORY_ID,CATEGORY_NAME) values (4,'History');
Insert into CATEGORIES (CATEGORY_ID,CATEGORY_NAME) values (5,'Biography');
Insert into CATEGORIES (CATEGORY_ID,CATEGORY_NAME) values (6,'Mystery');
Insert into CATEGORIES (CATEGORY_ID,CATEGORY_NAME) values (7,'Romance');
